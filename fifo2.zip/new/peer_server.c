#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>

#define PYTHON_TO_C "PYTHONTOC"

void send_to_server();

int main(int argc, char const *argv[]) {
    while (1) {
        send_to_server();
        sleep(2);  // Wait for a while before sending the next message
    }
    return 0;
}

void send_to_server() {
    char buffer[2000] = {0};
    int PORT_server = 9999;
    int sock = 0;
    struct sockaddr_in serv_addr;

    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        printf("\n Socket creation error \n");
        return;
    }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
    serv_addr.sin_port = htons(PORT_server);

    if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
        printf("\nConnection Failed \n");
        close(sock);
        return;
    }

    int fd = open(PYTHON_TO_C, O_RDONLY);
    if (fd < 0) {
        perror("Failed to open pipe");
        return;
    } else {
        printf("FIFO PYTHONTOC opened for reading\n");
    }

    int readbytes = read(fd, buffer, sizeof(buffer));
    if (readbytes > 0) {
        buffer[readbytes] = '\0';
        printf("Message read from Python: %s\n", buffer);
        send(sock, buffer, readbytes, 0);
        printf("\nMessage sent to server\n");
    }
    close(fd);
    close(sock);
}